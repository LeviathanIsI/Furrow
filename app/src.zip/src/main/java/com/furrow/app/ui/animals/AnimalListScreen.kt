package com.furrow.app.ui.animals

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.Pets
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.furrow.app.data.local.entity.Animal
import com.furrow.app.ui.components.AppScaffold
import com.furrow.app.ui.components.AppTopBar
import com.furrow.app.ui.components.DeleteConfirmationDialog
import com.furrow.app.ui.components.EmptyState
import com.furrow.app.ui.components.InlineStat
import com.furrow.app.ui.components.ItemActionSheet
import com.furrow.app.ui.components.ListRow
import com.furrow.app.ui.components.Panel
import com.furrow.app.ui.components.Tag
import com.furrow.app.ui.theme.AnimalsGlow
import com.furrow.app.ui.theme.AppSpacing
import com.furrow.app.ui.theme.TextSecondary
import com.furrow.app.ui.theme.Void

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AnimalListScreen(
    onAnimalClick: (Long) -> Unit,
    onAddAnimal: () -> Unit,
    viewModel: AnimalViewModel = hiltViewModel(),
) {
    val animals by viewModel.filteredAnimals.collectAsState()
    val allActive by viewModel.activeAnimals.collectAsState()
    val speciesList by viewModel.speciesList.collectAsState()
    val selectedSpecies by viewModel.selectedSpecies.collectAsState()
    val upcomingBirths by viewModel.upcomingBirths.collectAsState()
    val activeWithdrawals by viewModel.activeWithdrawals.collectAsState()

    var selectedAnimal by remember { mutableStateOf<Animal?>(null) }
    var animalToDelete by remember { mutableStateOf<Animal?>(null) }

    AppScaffold(
        topBar = {
            AppTopBar(title = "Animals")
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddAnimal,
                containerColor = AnimalsGlow,
                contentColor = Void,
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "Add Animal",
                )
            }
        },
    ) { padding ->
        if (animals.isEmpty() && selectedSpecies == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
            ) {
                EmptyState(
                    title = "No animals yet",
                    subtitle = "Add your first animal to start tracking your livestock.",
                    icon = {
                        Icon(
                            imageVector = Icons.Outlined.Pets,
                            contentDescription = null,
                            modifier = Modifier.size(28.dp),
                            tint = AnimalsGlow,
                        )
                    },
                    actionLabel = "Add Animal",
                    onAction = onAddAnimal,
                    modifier = Modifier.weight(1f),
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(
                    start = AppSpacing.md,
                    end = AppSpacing.md,
                    top = AppSpacing.md,
                    bottom = AppSpacing.xl,
                ),
                verticalArrangement = Arrangement.spacedBy(AppSpacing.md),
            ) {
                item(key = "species_filter") {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(AppSpacing.xs),
                    ) {
                        item {
                            Tag(
                                text = "All",
                                selected = selectedSpecies == null,
                                onClick = { viewModel.setSpeciesFilter(null) },
                                accentColor = AnimalsGlow,
                            )
                        }
                        items(speciesList, key = { it }) { species ->
                            Tag(
                                text = species.replaceFirstChar { it.uppercase() },
                                selected = selectedSpecies == species,
                                onClick = { viewModel.setSpeciesFilter(species) },
                                accentColor = AnimalsGlow,
                            )
                        }
                    }
                }

                item(key = "summary_stats") {
                    Panel {
                        InlineStat(
                            label = "Total Active",
                            value = "${allActive.size}",
                        )
                        InlineStat(
                            label = "Upcoming Births",
                            value = "${upcomingBirths.size}",
                        )
                        InlineStat(
                            label = "Active Withdrawals",
                            value = "${activeWithdrawals.size}",
                        )
                    }
                }

                if (animals.isNotEmpty()) {
                    item(key = "animals_panel") {
                        Panel(contentPadding = PaddingValues(0.dp)) {
                            animals.forEachIndexed { index, animal ->
                                val displayName = animal.name
                                    ?: "Unnamed ${animal.species.replaceFirstChar { it.uppercase() }}"
                                val subtitle = buildString {
                                    append(animal.breed)
                                    append(" \u2022 ")
                                    append(animal.sex.replaceFirstChar { it.uppercase() })
                                }

                                ListRow(
                                    title = displayName,
                                    subtitle = subtitle,
                                    metadata = animal.status.replaceFirstChar { it.uppercase() },
                                    onClick = { onAnimalClick(animal.id) },
                                    showDivider = index != animals.lastIndex,
                                    modifier = Modifier.combinedClickable(
                                        onClick = { onAnimalClick(animal.id) },
                                        onLongClick = { selectedAnimal = animal },
                                    ),
                                )
                            }
                        }
                    }
                } else {
                    item(key = "empty_filtered") {
                        EmptyState(
                            title = "No animals found",
                            subtitle = "No animals match the selected filter.",
                            icon = {
                                Icon(
                                    imageVector = Icons.Outlined.Pets,
                                    contentDescription = null,
                                    modifier = Modifier.size(28.dp),
                                    tint = TextSecondary,
                                )
                            },
                        )
                    }
                }
            }
        }
    }

    selectedAnimal?.let { animal ->
        ItemActionSheet(
            onDismiss = { selectedAnimal = null },
            onEdit = { onAnimalClick(animal.id) },
            onDelete = {
                animalToDelete = animal
                selectedAnimal = null
            },
        )
    }

    animalToDelete?.let { animal ->
        DeleteConfirmationDialog(
            itemName = animal.name ?: "Unnamed ${animal.species.replaceFirstChar { it.uppercase() }}",
            onConfirm = {
                viewModel.deleteAnimal(animal)
                animalToDelete = null
            },
            onDismiss = { animalToDelete = null },
        )
    }
}
