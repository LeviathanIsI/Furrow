package com.furrow.app.ui.garden.tabs

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.furrow.app.data.local.entity.HarvestLog
import com.furrow.app.ui.components.ListRow
import com.furrow.app.ui.components.Panel
import com.furrow.app.ui.theme.AppSpacing
import com.furrow.app.ui.theme.TextSecondary
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val zone: ZoneId = ZoneId.systemDefault()
private val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM d, yyyy")

internal data class HarvestTotal(
    val totalOz: Double,
    val totalCount: Int,
    val entryCount: Int,
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun HarvestsTab(
    harvests: List<HarvestLog>,
    plantingNames: Map<Long, String>,
    harvestTotals: Map<Long, HarvestTotal>,
    onLongPress: (HarvestLog) -> Unit,
) {
    val view = LocalView.current

    if (harvests.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No harvest logs yet", style = MaterialTheme.typography.titleMedium)
                Text("Use Add to log harvested yield", color = TextSecondary)
            }
        }
        return
    }

    val grouped = harvests.groupBy { it.plantingId }

    LazyColumn(
        contentPadding = PaddingValues(
            start = AppSpacing.md,
            end = AppSpacing.md,
            top = AppSpacing.md,
            bottom = AppSpacing.xl,
        ),
        verticalArrangement = Arrangement.spacedBy(AppSpacing.sm),
    ) {
        grouped.forEach { (plantingId, logs) ->
            item(key = "header_$plantingId") {
                Text(
                    text = plantingNames[plantingId] ?: "Unknown planting",
                    style = MaterialTheme.typography.titleMedium,
                )
                val total = harvestTotals[plantingId]
                total?.let {
                    Text(
                        text = buildString {
                            if (it.totalOz > 0) append(String.format(Locale.US, "%.1f oz", it.totalOz))
                            if (it.totalOz > 0 && it.totalCount > 0) append(" • ")
                            if (it.totalCount > 0) append("${it.totalCount} items")
                            append(" • ${it.entryCount} logs")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )
                }
            }

            item(key = "panel_$plantingId") {
                Panel(contentPadding = PaddingValues(0.dp)) {
                    logs.forEachIndexed { index, harvest ->
                        val harvestDate = Instant.ofEpochMilli(harvest.date).atZone(zone).toLocalDate()
                        ListRow(
                            modifier = Modifier.combinedClickable(
                                onClick = {},
                                onLongClick = {
                                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                                    onLongPress(harvest)
                                },
                            ),
                            title = harvestDate.format(dateFormatter),
                            subtitle = harvest.notes,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Outlined.Inventory2,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                )
                            },
                            trailingText = buildString {
                                harvest.amountOz?.let { append("${it}oz") }
                                harvest.count?.let {
                                    if (isNotBlank()) append(" • ")
                                    append("$it")
                                }
                            },
                            showDivider = index != logs.lastIndex,
                        )
                    }
                }
            }
        }
    }
}
