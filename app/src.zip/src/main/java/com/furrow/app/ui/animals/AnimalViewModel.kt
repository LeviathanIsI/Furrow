package com.furrow.app.ui.animals

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.furrow.app.data.local.entity.Animal
import com.furrow.app.data.local.entity.AnimalBreedInfo
import com.furrow.app.data.local.entity.BreedingRecord
import com.furrow.app.data.local.entity.FeedLog
import com.furrow.app.data.local.entity.FiberLog
import com.furrow.app.data.local.entity.HealthRecord
import com.furrow.app.data.local.entity.MilkLog
import com.furrow.app.data.local.entity.ProcessingRecord
import com.furrow.app.data.local.entity.WeightLog
import com.furrow.app.data.repository.AnimalRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class AnimalViewModel @Inject constructor(
    private val repository: AnimalRepository,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {

    private val animalId: Long? = savedStateHandle.get<Long>("animalId")

    // -- Species filter --

    val selectedSpecies = MutableStateFlow<String?>(null)

    val activeAnimals: StateFlow<List<Animal>> = repository.getActiveAnimals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredAnimals: StateFlow<List<Animal>> = combine(
        activeAnimals,
        selectedSpecies,
    ) { animals, species ->
        if (species == null) animals else animals.filter { it.species == species }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val speciesList: StateFlow<List<String>> = activeAnimals.map { animals ->
        animals.map { it.species }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // -- Breed reference data --

    val breedsBySpecies: StateFlow<List<AnimalBreedInfo>> = selectedSpecies.flatMapLatest { species ->
        if (species != null) repository.getBreedsBySpecies(species) else repository.getAllBreeds()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getBreedsForSpecies(species: String) = repository.getBreedsBySpecies(species)

    // -- Summary stats --

    private val now = Instant.now().toEpochMilli()

    val upcomingBirths: StateFlow<List<BreedingRecord>> = repository.getUpcomingBirths(now)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeWithdrawals: StateFlow<List<HealthRecord>> = repository.getActiveWithdrawals(now)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // -- Detail screen (driven by animalId nav arg) --

    val selectedAnimal: StateFlow<Animal?> = animalId?.let {
        repository.getAnimalById(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    } ?: MutableStateFlow(null)

    val healthRecords: StateFlow<List<HealthRecord>> = animalId?.let {
        repository.getHealthRecordsForAnimal(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } ?: MutableStateFlow(emptyList())

    val breedingRecords: StateFlow<List<BreedingRecord>> = animalId?.let {
        repository.getBreedingRecordsForAnimal(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } ?: MutableStateFlow(emptyList())

    val milkLogs: StateFlow<List<MilkLog>> = animalId?.let {
        repository.getMilkLogsForAnimal(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } ?: MutableStateFlow(emptyList())

    val fiberLogs: StateFlow<List<FiberLog>> = animalId?.let {
        repository.getFiberLogsForAnimal(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } ?: MutableStateFlow(emptyList())

    val weightLogs: StateFlow<List<WeightLog>> = animalId?.let {
        repository.getWeightLogsForAnimal(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } ?: MutableStateFlow(emptyList())

    val feedLogs: StateFlow<List<FeedLog>> = animalId?.let {
        repository.getFeedLogsForAnimal(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } ?: MutableStateFlow(emptyList())

    val processingRecords: StateFlow<List<ProcessingRecord>> = animalId?.let {
        repository.getProcessingRecordsForAnimal(it)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    } ?: MutableStateFlow(emptyList())

    // -- Lookups for edit mode --

    fun getAnimalById(id: Long) = repository.getAnimalById(id)
    fun getHealthRecordById(id: Long) = repository.getHealthRecordById(id)
    fun getBreedingRecordById(id: Long) = repository.getBreedingRecordById(id)
    fun getMilkLogById(id: Long) = repository.getMilkLogById(id)
    fun getFiberLogById(id: Long) = repository.getFiberLogById(id)
    fun getWeightLogById(id: Long) = repository.getWeightLogById(id)
    fun getFeedLogById(id: Long) = repository.getFeedLogById(id)
    fun getProcessingRecordById(id: Long) = repository.getProcessingRecordById(id)

    // -- Actions --

    fun addAnimal(animal: Animal) { viewModelScope.launch { repository.insertAnimal(animal) } }
    fun updateAnimal(animal: Animal) { viewModelScope.launch { repository.updateAnimal(animal) } }
    fun deleteAnimal(animal: Animal) { viewModelScope.launch { repository.deleteAnimal(animal) } }

    fun addHealthRecord(record: HealthRecord) { viewModelScope.launch { repository.insertHealthRecord(record) } }
    fun updateHealthRecord(record: HealthRecord) { viewModelScope.launch { repository.updateHealthRecord(record) } }
    fun deleteHealthRecord(record: HealthRecord) { viewModelScope.launch { repository.deleteHealthRecord(record) } }

    fun addBreedingRecord(record: BreedingRecord) { viewModelScope.launch { repository.insertBreedingRecord(record) } }
    fun updateBreedingRecord(record: BreedingRecord) { viewModelScope.launch { repository.updateBreedingRecord(record) } }
    fun deleteBreedingRecord(record: BreedingRecord) { viewModelScope.launch { repository.deleteBreedingRecord(record) } }

    fun addMilkLog(log: MilkLog) { viewModelScope.launch { repository.insertMilkLog(log) } }
    fun updateMilkLog(log: MilkLog) { viewModelScope.launch { repository.updateMilkLog(log) } }
    fun deleteMilkLog(log: MilkLog) { viewModelScope.launch { repository.deleteMilkLog(log) } }

    fun addFiberLog(log: FiberLog) { viewModelScope.launch { repository.insertFiberLog(log) } }
    fun updateFiberLog(log: FiberLog) { viewModelScope.launch { repository.updateFiberLog(log) } }
    fun deleteFiberLog(log: FiberLog) { viewModelScope.launch { repository.deleteFiberLog(log) } }

    fun addWeightLog(log: WeightLog) { viewModelScope.launch { repository.insertWeightLog(log) } }
    fun updateWeightLog(log: WeightLog) { viewModelScope.launch { repository.updateWeightLog(log) } }
    fun deleteWeightLog(log: WeightLog) { viewModelScope.launch { repository.deleteWeightLog(log) } }

    fun addFeedLog(log: FeedLog) { viewModelScope.launch { repository.insertFeedLog(log) } }
    fun updateFeedLog(log: FeedLog) { viewModelScope.launch { repository.updateFeedLog(log) } }
    fun deleteFeedLog(log: FeedLog) { viewModelScope.launch { repository.deleteFeedLog(log) } }

    fun addProcessingRecord(record: ProcessingRecord) { viewModelScope.launch { repository.insertProcessingRecord(record) } }
    fun updateProcessingRecord(record: ProcessingRecord) { viewModelScope.launch { repository.updateProcessingRecord(record) } }
    fun deleteProcessingRecord(record: ProcessingRecord) { viewModelScope.launch { repository.deleteProcessingRecord(record) } }

    fun insertBreed(breed: AnimalBreedInfo) { viewModelScope.launch { repository.insertBreed(breed) } }
    fun updateBreed(breed: AnimalBreedInfo) { viewModelScope.launch { repository.updateBreed(breed) } }
    fun deleteBreed(breed: AnimalBreedInfo) { viewModelScope.launch { repository.deleteBreed(breed) } }

    fun setSpeciesFilter(species: String?) { selectedSpecies.value = species }
}
