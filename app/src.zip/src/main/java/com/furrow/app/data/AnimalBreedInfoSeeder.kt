package com.furrow.app.data

import androidx.sqlite.db.SupportSQLiteDatabase

object AnimalBreedInfoSeeder {

    /** Gestation / incubation days by species, useful for calculating breeding due dates. */
    val GESTATION_DAYS: Map<String, Int> = mapOf(
        "chicken" to 21,
        "duck" to 28,
        "turkey" to 28,
        "goose" to 30,
        "quail" to 17,
        "goat" to 150,
        "sheep" to 147,
        "pig" to 114,
        "cow" to 283,
        "rabbit" to 31,
        "horse" to 340,
        "alpaca" to 345,
        "llama" to 350,
    )

    // ── Helper ──

    private fun a(
        db: SupportSQLiteDatabase,
        species: String,
        name: String,
        purpose: String? = null,
        temperament: String? = null,
        weight: String? = null,
        gestationDays: Int? = null,
        eggsPerYear: Int? = null,
        eggColor: String? = null,
        eggSize: String? = null,
        milkProductionGalDay: Double? = null,
        fiberYieldLbs: Double? = null,
        matureWeightLbs: Double? = null,
        dressPercentage: Double? = null,
        heatTolerance: Int? = null,
        coldTolerance: Int? = null,
        climateSuitability: String? = null,
        notes: String? = null,
    ) {
        db.execSQL(
            """INSERT INTO animal_breed_info (species, name, purpose, temperament, weight,
               gestation_days, eggs_per_year, egg_color, egg_size, milk_production_gal_day,
               fiber_yield_lbs, mature_weight_lbs, dress_percentage, heat_tolerance,
               cold_tolerance, climate_suitability, notes, is_custom)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)""",
            arrayOf<Any?>(
                species, name, purpose, temperament, weight,
                gestationDays, eggsPerYear, eggColor, eggSize, milkProductionGalDay,
                fiberYieldLbs, matureWeightLbs, dressPercentage, heatTolerance,
                coldTolerance, climateSuitability, notes,
            ),
        )
    }

    // ═══════════════════════════════════════════════════════════════
    //  PUBLIC API
    // ═══════════════════════════════════════════════════════════════

    /**
     * Inserts breed data for all non-chicken species.
     * Chicken breeds are already seeded by [PlantDatabaseSeeder.seedBreedInfo] and [NACatalogImporter].
     */
    fun seedBreeds(db: SupportSQLiteDatabase) {
        seedDucks(db)
        seedTurkeys(db)
        seedGeese(db)
        seedQuail(db)
        seedGoats(db)
        seedSheep(db)
        seedPigs(db)
        seedCattle(db)
        seedRabbits(db)
    }

    // ═══════════════════════════════════════════════════════════════
    //  DUCKS
    // ═══════════════════════════════════════════════════════════════

    private fun seedDucks(db: SupportSQLiteDatabase) {
        a(db, "duck", "Khaki Campbell",
            purpose = "layer", temperament = "Active, nervous",
            eggsPerYear = 300, eggColor = "White", eggSize = "Large",
            matureWeightLbs = 4.5, heatTolerance = 4, coldTolerance = 3,
            notes = "Top egg-producing duck breed, excellent forager")

        a(db, "duck", "Pekin",
            purpose = "dual", temperament = "Calm, friendly",
            eggsPerYear = 200, eggColor = "White", eggSize = "Extra Large",
            matureWeightLbs = 10.0, heatTolerance = 3, coldTolerance = 3,
            notes = "Fast-growing, most common commercial meat duck in the US")

        a(db, "duck", "Muscovy",
            purpose = "meat", temperament = "Quiet, docile",
            eggsPerYear = 120, eggColor = "White/Cream", eggSize = "Large",
            matureWeightLbs = 12.0, heatTolerance = 5, coldTolerance = 2,
            notes = "Lean meat, excellent pest control, perches like a chicken")

        a(db, "duck", "Indian Runner",
            purpose = "layer", temperament = "Active, upright",
            eggsPerYear = 280, eggColor = "White/Blue/Green", eggSize = "Large",
            matureWeightLbs = 4.0, heatTolerance = 4, coldTolerance = 3,
            notes = "Upright posture, great forager and slug control")

        a(db, "duck", "Welsh Harlequin",
            purpose = "dual", temperament = "Calm, docile",
            eggsPerYear = 280, eggColor = "White", eggSize = "Large",
            matureWeightLbs = 5.5, heatTolerance = 3, coldTolerance = 4,
            notes = "Excellent layer with decent carcass, auto-sexing at hatch")

        a(db, "duck", "Rouen",
            purpose = "meat", temperament = "Calm, easygoing",
            eggsPerYear = 140, eggColor = "Blue-Green", eggSize = "Large",
            matureWeightLbs = 9.0, heatTolerance = 3, coldTolerance = 4,
            notes = "Looks like a large Mallard, slow-growing with flavorful meat")

        a(db, "duck", "Cayuga",
            purpose = "dual", temperament = "Quiet, calm",
            eggsPerYear = 150, eggColor = "Black/Gray/White", eggSize = "Large",
            matureWeightLbs = 7.0, heatTolerance = 3, coldTolerance = 4,
            notes = "Iridescent black-green plumage, eggs darken early in season")

        a(db, "duck", "Swedish Blue",
            purpose = "dual", temperament = "Calm, hardy",
            eggsPerYear = 180, eggColor = "White/Blue/Green", eggSize = "Large",
            matureWeightLbs = 6.5, heatTolerance = 3, coldTolerance = 4,
            notes = "Good all-around homestead duck, calm temperament")
    }

    // ═══════════════════════════════════════════════════════════════
    //  TURKEYS
    // ═══════════════════════════════════════════════════════════════

    private fun seedTurkeys(db: SupportSQLiteDatabase) {
        a(db, "turkey", "Broad Breasted White",
            purpose = "meat", temperament = "Docile",
            matureWeightLbs = 38.0, dressPercentage = 82.0,
            heatTolerance = 2, coldTolerance = 3,
            notes = "Standard commercial turkey, rapid growth, cannot reproduce naturally")

        a(db, "turkey", "Broad Breasted Bronze",
            purpose = "meat", temperament = "Docile",
            matureWeightLbs = 38.0, dressPercentage = 80.0,
            heatTolerance = 2, coldTolerance = 3,
            notes = "Similar to BBW but with bronze plumage, rapid growth")

        a(db, "turkey", "Bourbon Red",
            purpose = "meat", temperament = "Calm, friendly",
            matureWeightLbs = 23.0, dressPercentage = 70.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Heritage breed, rich-flavored meat, good forager")

        a(db, "turkey", "Narragansett",
            purpose = "meat", temperament = "Calm, personable",
            matureWeightLbs = 22.0, dressPercentage = 68.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Heritage breed, excellent forager and pest control")

        a(db, "turkey", "Royal Palm",
            purpose = "ornamental", temperament = "Active, alert",
            matureWeightLbs = 16.0, dressPercentage = 65.0,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Striking black and white plumage, good pest control, smaller frame")

        a(db, "turkey", "Standard Bronze",
            purpose = "meat", temperament = "Calm, curious",
            matureWeightLbs = 25.0, dressPercentage = 70.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Heritage breed, natural mating, rich dark meat")

        a(db, "turkey", "Midget White",
            purpose = "meat", temperament = "Calm, gentle",
            matureWeightLbs = 13.0, dressPercentage = 72.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Small heritage breed ideal for small homesteads, broad breast for size")
    }

    // ═══════════════════════════════════════════════════════════════
    //  GEESE
    // ═══════════════════════════════════════════════════════════════

    private fun seedGeese(db: SupportSQLiteDatabase) {
        a(db, "goose", "Toulouse",
            purpose = "dual", temperament = "Calm, gentle",
            eggsPerYear = 35, matureWeightLbs = 20.0,
            heatTolerance = 2, coldTolerance = 4,
            notes = "Heavy breed, good for meat and foie gras, calm demeanor")

        a(db, "goose", "Embden",
            purpose = "meat", temperament = "Calm, quiet",
            eggsPerYear = 30, matureWeightLbs = 24.0,
            heatTolerance = 2, coldTolerance = 4,
            notes = "Largest common goose, fast-growing, white plumage")

        a(db, "goose", "Chinese",
            purpose = "layer", temperament = "Active, vocal",
            eggsPerYear = 60, matureWeightLbs = 10.0,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Excellent weeders, top egg producers among geese, loud alarm")

        a(db, "goose", "Pilgrim",
            purpose = "dual", temperament = "Calm, friendly",
            eggsPerYear = 40, matureWeightLbs = 13.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Auto-sexing breed, males white and females gray, gentle")

        a(db, "goose", "American Buff",
            purpose = "dual", temperament = "Docile, calm",
            eggsPerYear = 25, matureWeightLbs = 18.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Heritage breed, good meat quality, excellent disposition")

        a(db, "goose", "Sebastopol",
            purpose = "ornamental", temperament = "Gentle, friendly",
            eggsPerYear = 30, matureWeightLbs = 12.0,
            heatTolerance = 2, coldTolerance = 2,
            notes = "Ornamental curly feathers, needs shelter from wind and rain")
    }

    // ═══════════════════════════════════════════════════════════════
    //  QUAIL
    // ═══════════════════════════════════════════════════════════════

    private fun seedQuail(db: SupportSQLiteDatabase) {
        a(db, "quail", "Coturnix",
            purpose = "dual", temperament = "Calm, docile",
            eggsPerYear = 300, matureWeightLbs = 0.35,
            heatTolerance = 4, coldTolerance = 2,
            notes = "Matures in 6-8 weeks, prolific layer, easiest quail to raise")

        a(db, "quail", "Bobwhite",
            purpose = "meat", temperament = "Skittish, wild",
            eggsPerYear = 100, matureWeightLbs = 0.4,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Native North American, used for hunting preserves and meat")

        a(db, "quail", "California",
            purpose = "ornamental", temperament = "Shy, social",
            eggsPerYear = 65, matureWeightLbs = 0.35,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Distinctive head plume, native to western US")

        a(db, "quail", "Gambel's",
            purpose = "ornamental", temperament = "Shy, active",
            eggsPerYear = 50, matureWeightLbs = 0.3,
            heatTolerance = 5, coldTolerance = 2,
            notes = "Desert quail, distinctive top-knot, adapted to arid climates")

        a(db, "quail", "Button",
            purpose = "ornamental", temperament = "Timid, gentle",
            eggsPerYear = 100, matureWeightLbs = 0.1,
            heatTolerance = 4, coldTolerance = 1,
            notes = "Smallest quail (1-2 oz), often kept as pets or aviary birds")
    }

    // ═══════════════════════════════════════════════════════════════
    //  GOATS
    // ═══════════════════════════════════════════════════════════════

    private fun seedGoats(db: SupportSQLiteDatabase) {
        a(db, "goat", "Nigerian Dwarf",
            purpose = "dairy", temperament = "Friendly, playful",
            gestationDays = 150, milkProductionGalDay = 0.5,
            matureWeightLbs = 60.0, heatTolerance = 3, coldTolerance = 3,
            notes = "High butterfat (6-10%), small size ideal for small properties")

        a(db, "goat", "Nubian",
            purpose = "dairy", temperament = "Vocal, affectionate",
            gestationDays = 150, milkProductionGalDay = 0.75,
            matureWeightLbs = 150.0, heatTolerance = 5, coldTolerance = 2,
            notes = "High butterfat (4-5%), long pendulous ears, heat tolerant")

        a(db, "goat", "Alpine",
            purpose = "dairy", temperament = "Hardy, curious",
            gestationDays = 150, milkProductionGalDay = 1.0,
            matureWeightLbs = 150.0, heatTolerance = 3, coldTolerance = 4,
            notes = "Top milk volume producer, adaptable to most climates")

        a(db, "goat", "LaMancha",
            purpose = "dairy", temperament = "Calm, gentle",
            gestationDays = 150, milkProductionGalDay = 0.75,
            matureWeightLbs = 135.0, heatTolerance = 4, coldTolerance = 4,
            notes = "Distinctive very small ears, steady milk production, calm nature")

        a(db, "goat", "Saanen",
            purpose = "dairy", temperament = "Calm, easy to manage",
            gestationDays = 150, milkProductionGalDay = 1.0,
            matureWeightLbs = 160.0, heatTolerance = 2, coldTolerance = 4,
            notes = "Highest milk volume, all white, sensitive to sun")

        a(db, "goat", "Boer",
            purpose = "meat", temperament = "Docile, calm",
            gestationDays = 150, matureWeightLbs = 250.0,
            dressPercentage = 55.0,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Premier meat goat, fast growth rate, muscular build")

        a(db, "goat", "Kiko",
            purpose = "meat", temperament = "Hardy, independent",
            gestationDays = 150, matureWeightLbs = 200.0,
            dressPercentage = 52.0,
            heatTolerance = 4, coldTolerance = 4,
            notes = "Parasite resistant, low maintenance meat breed from New Zealand")

        a(db, "goat", "Pygmy",
            purpose = "pet", temperament = "Friendly, social",
            gestationDays = 150, milkProductionGalDay = 0.25,
            matureWeightLbs = 60.0, heatTolerance = 3, coldTolerance = 3,
            notes = "Compact, friendly, moderate milk with high butterfat")

        a(db, "goat", "Oberhasli",
            purpose = "dairy", temperament = "Gentle, quiet",
            gestationDays = 150, milkProductionGalDay = 0.75,
            matureWeightLbs = 125.0, heatTolerance = 3, coldTolerance = 4,
            notes = "Bay-colored Swiss breed, steady milk production, quiet temperament")

        a(db, "goat", "Toggenburg",
            purpose = "dairy", temperament = "Curious, active",
            gestationDays = 150, milkProductionGalDay = 0.75,
            matureWeightLbs = 135.0, heatTolerance = 2, coldTolerance = 5,
            notes = "Oldest registered dairy breed, excels in cold climates")
    }

    // ═══════════════════════════════════════════════════════════════
    //  SHEEP
    // ═══════════════════════════════════════════════════════════════

    private fun seedSheep(db: SupportSQLiteDatabase) {
        a(db, "sheep", "Merino",
            purpose = "wool", temperament = "Calm, gregarious",
            gestationDays = 147, fiberYieldLbs = 15.0,
            matureWeightLbs = 160.0, dressPercentage = 45.0,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Finest wool breed (17-24 micron), staple of wool industry")

        a(db, "sheep", "Suffolk",
            purpose = "meat", temperament = "Docile, friendly",
            gestationDays = 147, fiberYieldLbs = 5.0,
            matureWeightLbs = 275.0, dressPercentage = 52.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Black face and legs, fast growth, top terminal sire breed")

        a(db, "sheep", "Dorper",
            purpose = "meat", temperament = "Calm, easy to manage",
            gestationDays = 147,
            matureWeightLbs = 230.0, dressPercentage = 54.0,
            heatTolerance = 5, coldTolerance = 3,
            notes = "Hair sheep, no shearing needed, thrives in hot climates")

        a(db, "sheep", "Hampshire",
            purpose = "meat", temperament = "Docile, large",
            gestationDays = 147, fiberYieldLbs = 7.0,
            matureWeightLbs = 275.0, dressPercentage = 50.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Large meat breed, dark face, fast-growing lambs")

        a(db, "sheep", "Katahdin",
            purpose = "meat", temperament = "Hardy, docile",
            gestationDays = 147,
            matureWeightLbs = 175.0, dressPercentage = 50.0,
            heatTolerance = 5, coldTolerance = 4,
            notes = "Hair sheep, no shearing, parasite resistant, easy lambing")

        a(db, "sheep", "Corriedale",
            purpose = "dual", temperament = "Calm, easy to handle",
            gestationDays = 147, fiberYieldLbs = 13.0,
            matureWeightLbs = 200.0, dressPercentage = 48.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Dual-purpose wool and meat, medium-grade fleece (25-31 micron)")

        a(db, "sheep", "Icelandic",
            purpose = "dual", temperament = "Hardy, alert",
            gestationDays = 147, fiberYieldLbs = 5.0,
            matureWeightLbs = 150.0, dressPercentage = 48.0,
            heatTolerance = 2, coldTolerance = 5,
            notes = "Triple-purpose (wool, meat, milk), dual-coated fleece, extreme cold tolerance")

        a(db, "sheep", "Jacob",
            purpose = "dual", temperament = "Hardy, independent",
            gestationDays = 147, fiberYieldLbs = 4.0,
            matureWeightLbs = 130.0, dressPercentage = 46.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Multi-horned, spotted fleece, heritage breed, lean carcass")

        a(db, "sheep", "Rambouillet",
            purpose = "wool", temperament = "Calm, gregarious",
            gestationDays = 147, fiberYieldLbs = 12.0,
            matureWeightLbs = 225.0, dressPercentage = 48.0,
            heatTolerance = 4, coldTolerance = 4,
            notes = "French Merino type, fine wool (19-24 micron), range adaptable")

        a(db, "sheep", "Shetland",
            purpose = "wool", temperament = "Friendly, small",
            gestationDays = 147, fiberYieldLbs = 2.5,
            matureWeightLbs = 90.0, dressPercentage = 44.0,
            heatTolerance = 2, coldTolerance = 5,
            notes = "Extremely fine soft wool, 11 natural colors, small and hardy")
    }

    // ═══════════════════════════════════════════════════════════════
    //  PIGS
    // ═══════════════════════════════════════════════════════════════

    private fun seedPigs(db: SupportSQLiteDatabase) {
        a(db, "pig", "Berkshire",
            purpose = "meat", temperament = "Docile, friendly",
            gestationDays = 114, matureWeightLbs = 600.0,
            dressPercentage = 72.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Premium marbled pork, heritage breed, excellent flavor")

        a(db, "pig", "Large Black",
            purpose = "meat", temperament = "Docile, gentle",
            gestationDays = 114, matureWeightLbs = 700.0,
            dressPercentage = 70.0,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Excellent pastured pig, dark skin resists sunburn, endangered heritage breed")

        a(db, "pig", "Duroc",
            purpose = "meat", temperament = "Calm, hardy",
            gestationDays = 114, matureWeightLbs = 750.0,
            dressPercentage = 75.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Fast growth, excellent feed conversion, reddish-brown color")

        a(db, "pig", "Hampshire",
            purpose = "meat", temperament = "Active, muscular",
            gestationDays = 114, matureWeightLbs = 650.0,
            dressPercentage = 74.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Lean muscular carcass, distinctive black with white belt")

        a(db, "pig", "Yorkshire",
            purpose = "meat", temperament = "Calm, maternal",
            gestationDays = 114, matureWeightLbs = 650.0,
            dressPercentage = 74.0,
            heatTolerance = 2, coldTolerance = 3,
            notes = "Large White type, excellent mother, lean meat, pink skin sunburns")

        a(db, "pig", "Tamworth",
            purpose = "meat", temperament = "Active, excellent forager",
            gestationDays = 114, matureWeightLbs = 600.0,
            dressPercentage = 70.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Heritage bacon breed, outstanding forager, ginger-red color")

        a(db, "pig", "Gloucestershire Old Spots",
            purpose = "meat", temperament = "Docile, good natured",
            gestationDays = 114, matureWeightLbs = 600.0,
            dressPercentage = 70.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Orchard pig, great forager, lop ears, endangered heritage breed")

        a(db, "pig", "Mangalitsa",
            purpose = "meat", temperament = "Calm, slow-growing",
            gestationDays = 114, matureWeightLbs = 550.0,
            dressPercentage = 68.0,
            heatTolerance = 3, coldTolerance = 5,
            notes = "Wooly-coated lard breed, exceptionally cold hardy, rich-flavored pork")

        a(db, "pig", "Red Wattle",
            purpose = "meat", temperament = "Calm, gentle",
            gestationDays = 114, matureWeightLbs = 650.0,
            dressPercentage = 72.0,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Heritage breed with fleshy wattles, lean flavorful meat, good forager")

        a(db, "pig", "Kunekune",
            purpose = "pet", temperament = "Very friendly, docile",
            gestationDays = 114, matureWeightLbs = 200.0,
            dressPercentage = 60.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Small grazing pig, does not root aggressively, great for small acreage")
    }

    // ═══════════════════════════════════════════════════════════════
    //  CATTLE
    // ═══════════════════════════════════════════════════════════════

    private fun seedCattle(db: SupportSQLiteDatabase) {
        a(db, "cow", "Jersey",
            purpose = "dairy", temperament = "Gentle, curious",
            gestationDays = 283, milkProductionGalDay = 6.0,
            matureWeightLbs = 1000.0, dressPercentage = 52.0,
            heatTolerance = 4, coldTolerance = 3,
            notes = "Highest butterfat (4.9%), efficient feed-to-milk conversion, small frame")

        a(db, "cow", "Holstein",
            purpose = "dairy", temperament = "Calm, adaptable",
            gestationDays = 283, milkProductionGalDay = 9.0,
            matureWeightLbs = 1500.0, dressPercentage = 50.0,
            heatTolerance = 2, coldTolerance = 3,
            notes = "Highest milk volume breed worldwide, black and white, large frame")

        a(db, "cow", "Angus",
            purpose = "beef", temperament = "Calm, hardy",
            gestationDays = 283,
            matureWeightLbs = 1200.0, dressPercentage = 63.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Premium marbled beef, polled (naturally hornless), easy calving")

        a(db, "cow", "Hereford",
            purpose = "beef", temperament = "Docile, easy to handle",
            gestationDays = 283,
            matureWeightLbs = 1200.0, dressPercentage = 62.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Efficient grazers, distinctive red with white face, hardy")

        a(db, "cow", "Dexter",
            purpose = "dual", temperament = "Friendly, manageable",
            gestationDays = 283, milkProductionGalDay = 2.5,
            matureWeightLbs = 750.0, dressPercentage = 56.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Smallest British breed, ideal for small homesteads, triple-purpose")

        a(db, "cow", "Highland",
            purpose = "beef", temperament = "Hardy, calm",
            gestationDays = 283,
            matureWeightLbs = 1100.0, dressPercentage = 58.0,
            heatTolerance = 1, coldTolerance = 5,
            notes = "Long shaggy coat, extreme cold tolerance, lean meat, slow-growing")

        a(db, "cow", "Shorthorn",
            purpose = "dual", temperament = "Docile, versatile",
            gestationDays = 283, milkProductionGalDay = 4.0,
            matureWeightLbs = 1400.0, dressPercentage = 60.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Versatile dual-purpose, both beef and milking strains available")

        a(db, "cow", "Brown Swiss",
            purpose = "dairy", temperament = "Calm, strong",
            gestationDays = 283, milkProductionGalDay = 7.0,
            matureWeightLbs = 1400.0, dressPercentage = 54.0,
            heatTolerance = 4, coldTolerance = 4,
            notes = "Second highest milk yield, high protein milk, adaptable to many climates")
    }

    // ═══════════════════════════════════════════════════════════════
    //  RABBITS
    // ═══════════════════════════════════════════════════════════════

    private fun seedRabbits(db: SupportSQLiteDatabase) {
        a(db, "rabbit", "New Zealand",
            purpose = "meat", temperament = "Calm, docile",
            gestationDays = 31, matureWeightLbs = 11.0,
            dressPercentage = 60.0,
            heatTolerance = 2, coldTolerance = 4,
            notes = "Top commercial meat rabbit, fast growth, good feed conversion")

        a(db, "rabbit", "Californian",
            purpose = "meat", temperament = "Gentle, easy to handle",
            gestationDays = 31, matureWeightLbs = 10.0,
            dressPercentage = 60.0,
            heatTolerance = 2, coldTolerance = 4,
            notes = "White with dark points, excellent meat-to-bone ratio")

        a(db, "rabbit", "Rex",
            purpose = "dual", temperament = "Calm, friendly",
            gestationDays = 31, matureWeightLbs = 9.0,
            dressPercentage = 58.0,
            heatTolerance = 3, coldTolerance = 3,
            notes = "Velvety fur prized for pelts, good meat breed, gentle")

        a(db, "rabbit", "Flemish Giant",
            purpose = "meat", temperament = "Gentle, laid-back",
            gestationDays = 31, matureWeightLbs = 14.0,
            dressPercentage = 55.0,
            heatTolerance = 1, coldTolerance = 4,
            notes = "Largest rabbit breed, gentle giant, needs extra space")

        a(db, "rabbit", "Silver Fox",
            purpose = "dual", temperament = "Gentle, docile",
            gestationDays = 31, matureWeightLbs = 10.5,
            dressPercentage = 60.0,
            heatTolerance = 3, coldTolerance = 4,
            notes = "Heritage breed, dense stand-up fur, excellent meat dress-out")

        a(db, "rabbit", "Angora",
            purpose = "fiber", temperament = "Gentle, calm",
            gestationDays = 31, fiberYieldLbs = 1.5,
            matureWeightLbs = 8.0,
            heatTolerance = 1, coldTolerance = 5,
            notes = "Prized fiber breed, requires regular grooming, heat sensitive")

        a(db, "rabbit", "Holland Lop",
            purpose = "pet", temperament = "Friendly, playful",
            gestationDays = 31, matureWeightLbs = 4.0,
            heatTolerance = 2, coldTolerance = 3,
            notes = "Small lop-eared breed, popular pet, compact and gentle")

        a(db, "rabbit", "Lionhead",
            purpose = "pet", temperament = "Friendly, energetic",
            gestationDays = 31, matureWeightLbs = 3.5,
            heatTolerance = 2, coldTolerance = 3,
            notes = "Distinctive wool mane around head, small and social")
    }
}
